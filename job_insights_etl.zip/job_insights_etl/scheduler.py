import schedule
import time
import subprocess

def run_etl():
    print("🔁 Running ETL job...")
    subprocess.run(["python", "main.py"])
    print("✅ ETL job completed.")

schedule.every(1).hours.do(run_etl)


print("🔄 Starting test ETL scheduler (runs every 1 minute)...")

while True:
    schedule.run_pending()
    time.sleep(1)
