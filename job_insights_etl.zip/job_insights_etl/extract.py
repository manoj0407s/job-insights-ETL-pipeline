import os
import requests
from dotenv import load_dotenv

load_dotenv()

def extract_jobs():
    app_id = os.getenv("ADZUNA_APP_ID")
    app_key = os.getenv("ADZUNA_API_KEY")
    url = f"https://api.adzuna.com/v1/api/jobs/in/search/1?app_id={app_id}&app_key={app_key}&results_per_page=10"

    response = requests.get(url)
    response.raise_for_status()
    return response.json()["results"]
